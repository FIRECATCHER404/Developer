from flask import Flask, request, redirect, url_for, render_template_string

app = Flask(__name__)

# Simple template for password page
password_page_template = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Password</title>
    <style>
        body {
            background-color: black;
            color: #39ff14;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            border: 2px solid #39ff14;
            padding: 20px;
            width: 50%;
        }
        input[type="password"], input[type="submit"], button {
            background-color: black;
            color: #39ff14;
            border: 2px solid #39ff14;
            padding: 10px;
            margin-top: 15px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s;
        }
        input[type="submit"]:hover, button:hover {
            background-color: #39ff14;
            color: black;
        }
        button {
            display: block;
            margin: 10px auto;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Enter Password to View Log</h1>

    <form action="/view-log" method="POST">
        <input type="password" name="password" placeholder="Enter password"><br>
        <input type="submit" value="View Log">
    </form>

</body>
</html>
'''

@app.route('/view-log', methods=['GET', 'POST'])
def view_log():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == '333456':  # Replace with your actual password
            log_file_path = 'C:/users/freef/OneDrive/Desktop/my-htmls/Login/Dev.txt'
            with open(log_file_path, 'r') as log_file:
                log_content = log_file.read()
            return f"<pre>{log_content}</pre>"
        else:
            return render_template_string(password_page_template + '<p style="color:red;">Incorrect password!</p>')

    return render_template_string(password_page_template)

if __name__ == '__main__':
    app.run(debug=True)
